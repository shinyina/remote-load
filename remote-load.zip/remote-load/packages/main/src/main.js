import * as Vue from "vue";
import App from "./App.jsx";
window.Vue = Vue;

Vue.createApp(App).mount("#app");
